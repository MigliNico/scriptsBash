#!/bin/bash
appNames=()
fechas=$( jq -r '.apps[].versionInfo.lastConfigChangeAt' input.json ) 
INDEX=0
for i in ${fechas};
 do 
  let INDEX=${INDEX}+1
  FECHA_INICIO=$(date -d $i "+%s")
 FECHA_FIN=$(date +%s)
 DIFERENCIA=$(( $FECHA_FIN - $FECHA_INICIO ))
 DIVISIONSEG=$(($DIFERENCIA/86400))  
  if [ $DIVISIONSEG = 0 ]; then 
  appNames+=$( jq -r ".apps[${INDEX}].id" input.json ) ; 
   echo ${appNames}
  fi
done;
 echo ${appNames}
